<div class="fourcol first"> 
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Index Left") ) : ?>
        <?php endif; ?>
</div>

<div class="fourcol">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Index Center") ) : ?>
        <?php endif; ?>
</div>

<div class="fourcol">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Index Right") ) : ?>
        <?php endif; ?>
</div>