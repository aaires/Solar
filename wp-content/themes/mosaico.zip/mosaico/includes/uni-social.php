<ul class="social-menu">
<?php if (get_option('themnific_socials_rss') == "") {} else { ?>
<li class="sprite-rss"><a title="Rss Feed" href="<?php echo get_option('themnific_socials_rss');?>">Rss Feed</a></li><?php } ?>

<?php if (get_option('themnific_socials_googleplus') == "") {} else { ?>
<li class="sprite-google"><a title="Google+" href="<?php echo get_option('themnific_socials_googleplus');?>">Google+</a></li><?php } ?>

<?php if (get_option('themnific_socials_dl') == "") {} else { ?>
<li class="sprite-delicious"><a title="Delicious" href="<?php echo get_option('themnific_socials_dl');?>">Delicious</a></li><?php } ?>

<?php if (get_option('themnific_socials_ya') == "") {} else { ?>
<li class="sprite-yahoo"><a title="Yahoo!" href="<?php echo get_option('themnific_socials_ya');?>">Yahoo!</a></li><?php } ?>

<?php if (get_option('themnific_socials_sp') == "") {} else { ?>
<li class="sprite-stumbleupon"><a title="Stumbleupon" href="<?php echo get_option('themnific_socials_sp');?>">Stumbleupon</a></li><?php } ?>

<?php if (get_option('themnific_socials_sk') == "") {} else { ?>
<li class="sprite-skype"><a title="Skype" href="<?php echo get_option('themnific_socials_sk');?>">Skype</a></li><?php } ?>

<?php if (get_option('themnific_socials_behance') == "") {} else { ?>
<li class="sprite-behance"><a title="Behance" href="<?php echo get_option('themnific_socials_behance');?>">Behance</a></li><?php } ?>

<?php if (get_option('themnific_socials_po') == "") {} else { ?>
<li class="sprite-posterous"><a title="Posterous" href="<?php echo get_option('themnific_socials_po');?>">Posterous</a></li><?php } ?>

<?php if (get_option('themnific_socials_my') == "") {} else { ?>
<li class="sprite-myspace"><a title="MySpace" href="<?php echo get_option('themnific_socials_my');?>">MySpace</a></li><?php } ?>

<?php if (get_option('themnific_socials_la') == "") {} else { ?>
<li class="sprite-lastfm"><a title="Last FM" href="<?php echo get_option('themnific_socials_la');?>">Last FM</a></li><?php } ?>

<?php if (get_option('themnific_socials_li') == "") {} else { ?>
<li class="sprite-linkedin"><a title="Linked In" href="<?php echo get_option('themnific_socials_li');?>">Linked In</a></li><?php } ?>

<?php if (get_option('themnific_socials_fl') == "") {} else { ?>
<li class="sprite-flickr"><a title="Flickr" href="<?php echo get_option('themnific_socials_fl');?>">Flickr</a></li><?php } ?>

<?php if (get_option('themnific_socials_de') == "") {} else { ?>
<li class="sprite-deviantart"><a title="Deviant Art" href="<?php echo get_option('themnific_socials_de');?>">Deviant Art</a></li><?php } ?>

<?php if (get_option('themnific_socials_tu') == "") {} else { ?>
<li class="sprite-tumblr"><a title="Tumblr" href="<?php echo get_option('themnific_socials_tu');?>">Tumblr</a></li><?php } ?>

<?php if (get_option('themnific_socials_vi') == "") {} else { ?>
<li class="sprite-vimeo"><a title="Vimeo" href="<?php echo get_option('themnific_socials_vi');?>">Vimeo</a></li><?php } ?>

<?php if (get_option('themnific_socials_yo') == "") {} else { ?>
<li class="sprite-youtube"><a title="You Tube" href="<?php echo get_option('themnific_socials_yo');?>">You Tube</a></li><?php } ?>

<?php if (get_option('themnific_socials_tw') == "") {} else { ?>
<li class="sprite-twitter"><a title="Twitter" href="<?php echo get_option('themnific_socials_tw');?>">Twitter</a></li><?php } ?>

<?php if (get_option('themnific_socials_fa') == "") {} else { ?>
<li class="sprite-facebook"><a title="Facebook" href="<?php echo get_option('themnific_socials_fa');?>">Facebook</a></li><?php } ?>


</ul>
<div class="clear-floats"></div>