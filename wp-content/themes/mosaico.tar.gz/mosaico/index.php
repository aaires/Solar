<?php get_header(); ?>


<!-- for now stuff is in the header file -->

<?php get_footer(); ?>