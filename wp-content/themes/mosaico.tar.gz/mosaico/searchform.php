<form class="searchform" method="get" action="<?php  echo home_url(); ?>">
<input type="text" name="s" class="s" size="30" value="Search" onfocus="if (this.value = '') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search...';}" /><input type="submit" class="searchSubmit" value="" />
</form>